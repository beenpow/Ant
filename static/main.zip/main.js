// websocket 접속
const socket = io.connect('http://192.168.0.28:5000', {transports:['websocket']});

socket.on('connect', () => {
    console.log('서버와 연결이 완료되었습니다.!');
});

socket.on('disconnect', () => {
    console.log('서버와의 연결이 해제되었습니다.');
});



// main page text typing
let target = document.querySelector('#dynamic');

function randomString(){
    let stringArr = ["Let's Go Korail!", "Learn to BigData!",
        "Learn to AI!", "Learn to Object Detection!", 'Learn to Computer Vision!']
    let selectString = stringArr[Math.floor(Math.random() * stringArr.length)];
    let selectStringArr = selectString.split("");
    
    return selectStringArr
}

//타이핑 리셋
function resetTyping(){
    target.textContent = "";
    dynamic(randomString());
}

//한글자씩 텍스트 출력 함수
function dynamic(randomArr){

    if(randomArr.length > 0){
        target.textContent += randomArr.shift();
        setTimeout(function(){
            dynamic(randomArr);
        }    , 80);
    }else{
        setTimeout(resetTyping, 1000);
    }
}

dynamic(randomString());

//커서 깜빡임 효과
function blink(){
    target.classList.toggle('active');
}

setInterval(blink, 500);



// 파일 업로드 관련
let uploadedFile;

// 드롭박스 영역 요소 가져오기
const dropBox = document.getElementById('dropBox');
const title = dropBox.querySelector('h3');

dropBox.addEventListener('dragover', function (e) {
    e.preventDefault();
    dropBox.classList.add('drag-over');
});

dropBox.addEventListener('dragleave', function () {
    dropBox.classList.remove('drag-over');
});

dropBox.addEventListener('drop', function (e) {
    e.preventDefault();
    dropBox.classList.remove('drag-over');

    const file = [...e.dataTransfer.files];
    if (file.length > 0) {
        uploadedFile = file[0];
        title.innerHTML = file.map(v => v.name).join('<br>');
    }
});



// kakao map api
// 엔터키로 새 창에서 지도 검색
function handleKeyPress(event) {
    if (event.key == 'Enter') {
        openMapWindow();
        processVideo();
    };
};

// 새로운 창에서 지도 활성화
function openMapWindow() {
    const location = document.getElementById('locationInput').value;
    if (!location) {
        alert("역명을 입력하세요.")
        return;
    };
    // 새 창을 열고 지도 HTML을 추가
    const newWindow = window.open(`mapResult.html?location=${encodeURIComponent(location)}`, '_blank');
    // 새 창이 열리면 최대화 설정
    newWindow.onload = function() {
        newWindow.moveTo(0, 0);
        newWindow.resizeTo(screen.width, screen.height);
    };
    processVideo();
};



// 프레임 추출 및 전송
function processVideo() {
    if (!uploadedFile) {
        alert("동영상을 업로드하세요.");
        return;
    }

    const video = document.createElement("video");
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    video.src = URL.createObjectURL(uploadedFile);

    video.addEventListener("loadeddata", () => {
        const totalFrames = Math.floor(video.duration * video.videoWidth);
        let frameIndex = 0;

        video.play();

        // 프레임 전송 함수
        function sendNextFrame() {
            if (video.paused || video.ended) return;

            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;

            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const base64Frame = canvas.toDataURL('image/jpeg');

            socket.emit("frame", {frame:base64Frame, frame_index:frameIndex});
            console.log(`프레임 ${frameIndex} 전송`);
            frameIndex++;
        }

        // 서버로부터 처리 완료 신호를 받으면 다음 프레임 전송
        socket.on("frame_processed", (data) => {
            console.log(`프레임 ${data.frame_index} 처리 완료`);
            sendNextFrame();
        });
        sendNextFrame(); // 첫 프레임 전송
    });
}






// 프레임 추출 및 전송
function processVideo() {
    if (!uploadedFile) {
        alert('파일을 업로드하세요.');
        return;
    }

    const video = document.createElement('video')
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d');

    video.src = URL.createObjectURL(uploadedFile);
    video.muted = true;
    video.play();

    video.addEventListener('loadeddata', () => {
        video.currentTime = 0;
    });
    
    let frameID = 0;

    video.addEventListener('seeked', () => {
        if (video.currentTime >= video.duration) {
            socket.emit('end_video');
            return;
        }

        canvas.width = video.videoWidth / 2;
        canvas.height = video.videoHeight / 2;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        canvas.toBlob(blob => {
            const reader = new FileReader();
            reader.onload = function (e) {
                const frameData = e.target.result;
                socket.emit('video_frame', {frameID: frameID++, frameData});
            };
            reader.readAsArrayBuffer(blob);
        }, 'image/jpeg');

        video.currentTime += 1/24; // 1초 간격으로 프레임 추출
    });
}